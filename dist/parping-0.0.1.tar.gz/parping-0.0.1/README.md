Simple parallel ipv4 ping util.

Accepts ip range input, e.g. 10.10.10.1-255
returns 2 lists, responding and non-responding ips

originated from need to quick-check many IPs after disaster-recovery excercises.
intended to be moldable.